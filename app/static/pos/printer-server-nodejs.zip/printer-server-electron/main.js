const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const net = require('net');
const os = require('os');
const escpos = require('escpos');
escpos.Network = require('escpos-network');

let mainWindow = null;
let tray = null;
let pollingInterval = null;
let config = null;
let lastItemId = 0;
let cancelPrinting = false;  // 印刷キャンセルフラグ
let activeSockets = [];      // 現在接続中のソケット一覧
const processingItemIds = new Set();  // 処理中のアイテムID（二重印刷防止）

// 設定ファイルのパス
const configPath = path.join(app.getPath('userData'), 'config.json');
const logPath = path.join(app.getPath('userData'), 'debug.log');
const lastItemIdPath = path.join(app.getPath('userData'), 'last_item_id.json');

// lastItemIdをファイルから読み込む
function loadLastItemId() {
    try {
        if (fs.existsSync(lastItemIdPath)) {
            const data = JSON.parse(fs.readFileSync(lastItemIdPath, 'utf8'));
            lastItemId = data.lastItemId || 0;
            console.log(`[lastItemId] ファイルから読み込み: ${lastItemId}`);
            return true; // ファイルが存在した
        }
        return false; // ファイルがない（初回インストール）
    } catch (e) {
        console.error('[lastItemId] 読み込みエラー:', e.message);
        return false;
    }
}

// 初回起動時にサーバーから最新item_idを取得して初期化
async function initLastItemIdFromServer() {
    if (!config || !config.herokuUrl || !config.storeId || !config.apiKey) return;
    try {
        const url = `${config.herokuUrl}/api/printer-server/new-orders?store_id=${config.storeId}&api_key=${encodeURIComponent(config.apiKey)}&init=true`;
        console.log('[lastItemId] サーバーから最新item_idを取得中...');
        const response = await axios.get(url, { timeout: 10000 });
        if (response.data && response.data.latest_item_id !== undefined) {
            lastItemId = response.data.latest_item_id;
            saveLastItemId(lastItemId);
            console.log(`[lastItemId] サーバーから初期化: ${lastItemId}`);
            writeLog(`[lastItemId] 初回起動: サーバーから最新item_id=${lastItemId}で初期化`);
        }
    } catch (e) {
        console.error('[lastItemId] サーバー初期化エラー:', e.message);
    }
}

// lastItemIdをファイルに保存する
function saveLastItemId(id) {
    try {
        fs.writeFileSync(lastItemIdPath, JSON.stringify({ lastItemId: id }), 'utf8');
        console.log(`[lastItemId] ファイルに保存: ${id}`);
    } catch (e) {
        console.error('[lastItemId] 保存エラー:', e.message);
    }
}

// ログ出力関数
function writeLog(message) {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] ${message}\n`;
    fs.appendFileSync(logPath, logMessage, 'utf8');
    console.log(logMessage);
}

// Herokuに重要ログを送信する関数
async function sendLogToHeroku(logType, data) {
    if (!config || !config.herokuUrl || !config.storeId || !config.apiKey) return;
    try {
        await axios.post(`${config.herokuUrl}/api/printer-server/log-info`, {
            store_id: config.storeId,
            api_key: config.apiKey,
            log_type: logType,
            ...data
        }, { timeout: 5000 });
    } catch (e) {
        writeLog(`[Herokuログ送信失敗] ${e.message}`);
    }
}

// 設定を読み込む
function loadConfig() {
    try {
        if (fs.existsSync(configPath)) {
            const data = fs.readFileSync(configPath, 'utf8');
            config = JSON.parse(data);
            
            // 旧形式から新形式への移行
            if (config.printerIp && !config.printers) {
                config.printers = [{
                    id: 1,
                    name: 'メインプリンタ',
                    ip: config.printerIp,
                    port: config.printerPort || 9100,
                    enabled: true
                }];
                delete config.printerIp;
                delete config.printerPort;
                saveConfig(config);
            }
            
            return config;
        }
    } catch (error) {
        console.error('設定ファイルの読み込みエラー:', error);
    }
    // 設定ファイルが存在しない場合はデフォルト設定を返す
    return {
        enabled: false,
        herokuUrl: '',
        storeId: 1,
        apiKey: '',
        interval: 10000,
        printers: []
    };
}

// プリンタ一覧をHerokuに同期する
async function syncPrintersToHeroku() {
    if (!config || !config.herokuUrl || !config.storeId || !config.apiKey) return;
    try {
        const printers = (config.printers || []).map(p => ({
            name: p.name,
            kind: 'printer_server',
            connection: `printer-server://${p.name}`,
            width: 42,
            enabled: p.enabled ? 1 : 0
        }));
        await axios.post(`${config.herokuUrl}/api/printer-server/register-printers`, {
            store_id: config.storeId,
            api_key: config.apiKey,
            printers: printers,
            printer_server_url: 'http://localhost:3001'
        }, { timeout: 10000 });
        writeLog(`[Heroku同期] プリンタ一覧を同期しました (${printers.length}台)`);
    } catch (e) {
        writeLog(`[Heroku同期エラー] ${e.message}`);
    }
}

// 設定を保存する
function saveConfig(newConfig) {
    try {
        fs.writeFileSync(configPath, JSON.stringify(newConfig, null, 2), 'utf8');
        config = newConfig;
        return true;
    } catch (error) {
        console.error('設定ファイルの保存エラー:', error);
        return false;
    }
}

// メインウィンドウを作成
function createWindow() {
    mainWindow = new BrowserWindow({
        width: 700,
        height: 800,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        },
        icon: path.join(__dirname, 'assets', 'icon.png')
    });

    mainWindow.loadFile('index.html');

    mainWindow.on('close', (event) => {
        if (!app.isQuitting) {
            event.preventDefault();
            mainWindow.hide();
        }
        return false;
    });
}

// システムトレイを作成
function createTray() {
    const iconPath = path.join(__dirname, 'assets', 'icon.png');
    const trayIcon = nativeImage.createFromPath(iconPath);
    tray = new Tray(trayIcon.resize({ width: 16, height: 16 }));

    const contextMenu = Menu.buildFromTemplate([
        {
            label: '設定を開く',
            click: () => {
                mainWindow.show();
            }
        },
        {
            label: 'ポーリング状態',
            enabled: false
        },
        {
            type: 'separator'
        },
        {
            label: '終了',
            click: () => {
                app.isQuitting = true;
                app.quit();
            }
        }
    ]);

    tray.setToolTip('プリンターサーバー');
    tray.setContextMenu(contextMenu);

    tray.on('click', () => {
        mainWindow.show();
    });
}

// 自動起動を設定
function setupAutoLaunch() {
    app.setLoginItemSettings({
        openAtLogin: true,
        path: app.getPath('exe')
    });
}

// プリンタに印刷（設定ベース）
async function printToDevice(printerConfig, orderData, settings) {
    const iconv = require('iconv-lite');
    
    const isStarPRNT = printerConfig.command_mode === 'starprnt';
    
    // テスト印刷と同じ直接TCPソケット方式でコマンドを生成
    const commands = [];
    
    if (isStarPRNT) {
        // StarPRNT初期化
        commands.push(Buffer.from([0x1B, 0x40]));          // ESC @ (初期化)
        commands.push(Buffer.from([0x1B, 0x24, 0x01]));    // ESC $ 1 (Shift JIS漢字モードON)
        // StarPRNT 180度回転（ESC GS h 0 k m n）
        if (printerConfig.rotate_180) {
            commands.push(Buffer.from([0x1B, 0x1D, 0x68, 0x30, 0x01, 0x00, 0x00]));  // ESC GS h 0 1 0 0
        }
    } else {
        // ESC/POS (Epson) 初期化
        commands.push(Buffer.from([0x1B, 0x40]));          // ESC @ (初期化)
        commands.push(Buffer.from([0x1B, 0x74, 0x00]));    // ESC t 0 (日本語)
        commands.push(Buffer.from([0x1C, 0x43, 0x01]));    // FS C 1 (漢字モードON)
        // 180度回転（アップサイドダウン）
        if (printerConfig.rotate_180) {
            commands.push(Buffer.from([0x1B, 0x7B, 0x01]));  // ESC { 1 (上下反転ON)
        }
    }
    
    // 印刷モードによって処理を分岐
    if (settings.print_mode === 'receipt') {
        buildReceiptCommands(commands, iconv, orderData, settings);
    } else {
        if (isStarPRNT) {
            buildStarPRNTKitchenCommands(commands, iconv, orderData, settings, printerConfig.rotate_180);
        } else {
            buildKitchenCommands(commands, iconv, orderData, settings, printerConfig.rotate_180);
        }
    }
    
    // カットコマンド
    if (isStarPRNT) {
        // StarPRNT: ESC d 3 (カット位置まで送ってパーシャルカット)
        commands.push(Buffer.from([0x1B, 0x64, 0x03]));
    } else {
        // ESC/POS: GS V 65 8 (8ドット≈1mmフィードしてフルカット)
        commands.push(Buffer.from([0x1D, 0x56, 0x41, 0x08]));
    }
    
    // 全コマンドを結合して送信
    const fullCommand = Buffer.concat(commands);
    writeLog(`[印刷開始] ${printerConfig.name} (${printerConfig.ip}:${printerConfig.port}) mode=${settings.print_mode}`);
    await sendToPrinter(printerConfig.ip, printerConfig.port, fullCommand);
    writeLog(`[印刷完了] ${printerConfig.name}`);
    // Herokuに印刷成功ログを送信
    await sendLogToHeroku('print_success', {
        printer_name: printerConfig.name,
        printer_ip: printerConfig.ip,
        print_mode: settings.print_mode,
        order_id: orderData.id || null,
        table_name: orderData.table_name || null
    });
}

// 伝票モード（レシート）のコマンド構築
function buildReceiptCommands(commands, iconv, orderData, settings) {
    // タイトル表示
    if (settings.show_title) {
        const alignCode = settings.title_align === 'center' ? 0x01 : settings.title_align === 'right' ? 0x02 : 0x00;
        commands.push(Buffer.from([0x1B, 0x61, alignCode]));
        if (settings.title_bold) commands.push(Buffer.from([0x1B, 0x45, 0x01]));
        const titleSize = Math.min(Math.max(settings.title_size || 2, 1), 3);
        const sizeCode = (titleSize - 1) * 0x11;
        commands.push(Buffer.from([0x1D, 0x21, sizeCode]));
        commands.push(iconv.encode((settings.title_text || 'ご注文内容') + '\n', 'Shift_JIS'));
        commands.push(Buffer.from([0x1D, 0x21, 0x00]));
        commands.push(Buffer.from([0x1B, 0x45, 0x00]));
        commands.push(Buffer.from([0x1B, 0x61, 0x00]));
    }
    
    if (settings.show_separator) commands.push(iconv.encode('========================\n', 'Shift_JIS'));
    
    commands.push(iconv.encode(`注文ID: ${orderData.id || ''}\n`, 'Shift_JIS'));
    commands.push(iconv.encode(`テーブル: ${orderData.table_name || ''}\n`, 'Shift_JIS'));
    
    if (settings.show_datetime) {
        const datetime = formatDateTime(orderData.datetime, settings.datetime_format);
        commands.push(iconv.encode(`日時: ${datetime}\n`, 'Shift_JIS'));
    }
    
    if (settings.show_separator) commands.push(iconv.encode('------------------------\n', 'Shift_JIS'));
    
    if (orderData.items && orderData.items.length > 0) {
        orderData.items.forEach(item => {
            if (settings.show_price) {
                const itemLine = `${item.menu_name || item.name} x${item.qty || item.quantity}`;
                const price = (item.price || 0) * (item.qty || item.quantity || 1);
                const priceLine = `¥${price.toLocaleString()}`;
                const spacer = ' '.repeat(Math.max(1, 42 - itemLine.length - priceLine.length));
                commands.push(iconv.encode(`${itemLine}${spacer}${priceLine}\n`, 'Shift_JIS'));
            } else {
                commands.push(iconv.encode(`${item.menu_name || item.name} x${item.qty || item.quantity}\n`, 'Shift_JIS'));
            }
        });
    }
    
    if (settings.show_price && orderData.subtotal !== undefined) {
        if (settings.show_separator) commands.push(iconv.encode('------------------------\n', 'Shift_JIS'));
        commands.push(iconv.encode(`小計: ¥${(orderData.subtotal || 0).toLocaleString()}\n`, 'Shift_JIS'));
        commands.push(iconv.encode(`税: ¥${(orderData.tax || 0).toLocaleString()}\n`, 'Shift_JIS'));
        commands.push(Buffer.from([0x1B, 0x45, 0x01]));
        commands.push(iconv.encode(`合計: ¥${(orderData.total || 0).toLocaleString()}\n`, 'Shift_JIS'));
        commands.push(Buffer.from([0x1B, 0x45, 0x00]));
    }
}

/// StarPRNT 厄房モード（KDS）のコマンド構築
// 注意: StarPRNTはShift JISエンコードを使用する
function buildStarPRNTKitchenCommands(commands, iconv, orderData, settings, rotate_180) {
    const firstItem = orderData.items && orderData.items.length > 0 ? orderData.items[0] : null;
    const isNew = firstItem && firstItem.is_new !== undefined ? firstItem.is_new : true;
    const label = isNew ? '[新規]' : '[追加]';
    const tableName = orderData.table_name || '';
    const time = formatDateTime(orderData.datetime, settings.kitchen_datetime_format || 'HH:mm');

    // ヘッダー行のコマンド群
    const headerCmds = [];
    headerCmds.push(Buffer.from([0x1B, 0x1D, 0x61, 0x00]));  // ESC GS a 0 (左揃え)
    headerCmds.push(Buffer.from([0x1B, 0x45]));               // ESC E (太字ON)
    headerCmds.push(Buffer.from([0x1B, 0x69, 0x01, 0x01]));   // ESC i 1 1 (2倍サイズ)
    headerCmds.push(iconv.encode(`${label} ${tableName}  ${time}`, 'Shift_JIS'));
    headerCmds.push(Buffer.from([0x1B, 0x46]));               // ESC F (太字OFF)
    headerCmds.push(Buffer.from([0x1B, 0x69, 0x00, 0x00]));   // ESC i 0 0 (サイズリセット)
    headerCmds.push(iconv.encode('\n', 'Shift_JIS'));

    // メニュー行のコマンド群
    const itemCmds = [];
    if (orderData.items && orderData.items.length > 0) {
        const items = rotate_180 ? [...orderData.items].reverse() : orderData.items;
        items.forEach(item => {
            itemCmds.push(Buffer.from([0x1B, 0x45]));               // ESC E (太字ON)
            itemCmds.push(Buffer.from([0x1B, 0x69, 0x01, 0x01]));   // ESC i 1 1 (2倍サイズ)
            itemCmds.push(iconv.encode(`${item.menu_name || item.name} x${item.qty || item.quantity}`, 'Shift_JIS'));
            itemCmds.push(Buffer.from([0x1B, 0x46]));               // ESC F (太字OFF)
            itemCmds.push(Buffer.from([0x1B, 0x69, 0x00, 0x00]));   // ESC i 0 0 (サイズリセット)
            itemCmds.push(iconv.encode('\n', 'Shift_JIS'));
        });
    }

    // 180度回転時は行順を逆にする（メニュー行→ヘッダー行の順で送信）
    if (rotate_180) {
        itemCmds.forEach(cmd => commands.push(cmd));
        headerCmds.forEach(cmd => commands.push(cmd));
    } else {
        headerCmds.forEach(cmd => commands.push(cmd));
        itemCmds.forEach(cmd => commands.push(cmd));
    }
}

/// 厨房モード（KDS）のコマンド構築
function buildKitchenCommands(commands, iconv, orderData, settings, rotate_180) {
    const firstItem = orderData.items && orderData.items.length > 0 ? orderData.items[0] : null;
    const isNew = firstItem && firstItem.is_new !== undefined ? firstItem.is_new : true;
    const label = isNew ? '[新規]' : '[追加]';
    const tableName = orderData.table_name || '';
    const time = formatDateTime(orderData.datetime, settings.kitchen_datetime_format || 'HH:mm');

    // ヘッダー行のコマンド群
    const headerCmds = [];
    headerCmds.push(Buffer.from([0x1B, 0x61, 0x00]));  // 左揃え
    headerCmds.push(Buffer.from([0x1B, 0x45, 0x01]));  // 太字ON
    headerCmds.push(Buffer.from([0x1D, 0x21, 0x11]));  // 2倍サイズ
    headerCmds.push(iconv.encode(`${label} ${tableName}  ${time}`, 'Shift_JIS'));
    headerCmds.push(Buffer.from([0x1B, 0x45, 0x00]));  // 太字OFF
    headerCmds.push(Buffer.from([0x1D, 0x21, 0x00]));  // サイズを1倍に戻してから改行（行送り量を1倍高さに）
    headerCmds.push(iconv.encode('\n', 'Shift_JIS'));  // 行確定（1倍サイズで改行）

    // メニュー行のコマンド群
    const itemCmds = [];
    if (orderData.items && orderData.items.length > 0) {
        const items = rotate_180 ? [...orderData.items].reverse() : orderData.items;
        items.forEach(item => {
            itemCmds.push(Buffer.from([0x1B, 0x45, 0x01]));  // 太字ON
            itemCmds.push(Buffer.from([0x1D, 0x21, 0x11]));  // 2倍サイズ
            itemCmds.push(iconv.encode(`${item.menu_name || item.name} x${item.qty || item.quantity}`, 'Shift_JIS'));
            itemCmds.push(Buffer.from([0x1B, 0x45, 0x00]));  // 太字OFF
            itemCmds.push(Buffer.from([0x1D, 0x21, 0x00]));  // サイズを1倍に戻してから改行（行送り量を1倍高さに）
            itemCmds.push(iconv.encode('\n', 'Shift_JIS'));  // 行確定（1倍サイズで改行）
        });
    }

    // 180度回転時は行順を逆にする（メニュー行→ヘッダー行の順で送信）
    if (rotate_180) {
        itemCmds.forEach(cmd => commands.push(cmd));
        headerCmds.forEach(cmd => commands.push(cmd));
    } else {
        headerCmds.forEach(cmd => commands.push(cmd));
        itemCmds.forEach(cmd => commands.push(cmd));
    }
}

// 日時フォーマット関数
function formatDateTime(datetime, format) {
    if (!datetime) {
        datetime = new Date();
    } else if (typeof datetime === 'string') {
        datetime = new Date(datetime);
    }
    
    const year = datetime.getFullYear();
    const month = String(datetime.getMonth() + 1).padStart(2, '0');
    const day = String(datetime.getDate()).padStart(2, '0');
    const hours = String(datetime.getHours()).padStart(2, '0');
    const minutes = String(datetime.getMinutes()).padStart(2, '0');
    const seconds = String(datetime.getSeconds()).padStart(2, '0');
    
    return format
        .replace('YYYY', year)
        .replace('MM', month)
        .replace('DD', day)
        .replace('HH', hours)
        .replace('mm', minutes)
        .replace('ss', seconds);
}

// 印刷済みフラグをサーバーに送信する関数
async function markPrinted(itemIds, printType) {
    if (!itemIds || itemIds.length === 0) return;
    try {
        const url = `${config.herokuUrl}/api/printer-server/mark-printed`;
        const response = await axios.post(url, {
            store_id: config.storeId,
            api_key: config.apiKey,
            item_ids: itemIds,
            print_type: printType
        }, { timeout: 10000 });
        if (response.data && response.data.ok) {
            writeLog(`[mark-printed] ${printType}: ${itemIds.length}件更新完了`);
        } else {
            writeLog(`[mark-printed] ${printType}: 更新失敗 - ${JSON.stringify(response.data)}`);
        }
    } catch (e) {
        writeLog(`[mark-printed] ${printType}: エラー - ${e.message}`);
        console.error('[mark-printed] エラー:', e.message);
    }
}

// 新規注文をチェックしてプリント（プリンターごとに独立してポーリング）
async function checkAndPrint() {
    if (!config || !config.enabled) return;
    if (!config.printers || config.printers.length === 0) return;

    // 有効なプリンタのみフィルタリング
    const enabledPrinters = config.printers.filter(p => p.enabled);
    if (enabledPrinters.length === 0) {
        console.log('有効なプリンタがありません');
        return;
    }

    // 各プリンターごとに独立して処理
    for (const printer of enabledPrinters) {
        try {
            // まずプリンタ設定を取得してprint_modeを確認
            const settingsUrl = `${config.herokuUrl}/api/printer-server/print-settings/${encodeURIComponent(printer.name)}?store_id=${config.storeId}&api_key=${encodeURIComponent(config.apiKey)}`;
            let settings;
            try {
                const settingsResponse = await axios.get(settingsUrl, { timeout: 10000 });
                settings = settingsResponse.data.settings;
            } catch (settingsError) {
                console.error(`[設定取得失敗] ${printer.name}: ${settingsError.message}`);
                continue;
            }

            // print_modeに基づいてprint_typeを決定
            const printType = (settings.print_mode === 'kitchen') ? 'kitchen' : 'receipt';

            // DBベースのフィルタリングでnew-orders APIを呼び出す
            const url = `${config.herokuUrl}/api/printer-server/new-orders?store_id=${config.storeId}&api_key=${encodeURIComponent(config.apiKey)}&print_type=${printType}&since_item_id=${lastItemId}`;
            console.log(`[DEBUG] ${printer.name} (${printType}) リクエストURL:`, url);

            const response = await axios.get(url, { timeout: 10000 });

            if (!response.data || !response.data.items || response.data.items.length === 0) {
                continue; // このプリンターは印刷不要
            }

            const items = response.data.items;
            console.log(`[${printer.name}] 新規OrderItem: ${items.length}件 (${printType})`);
            writeLog(`[新規注文] ${printer.name} (${printType}): ${items.length}件検出: item_ids=[${items.map(i => i.item_id).join(',')}]`);

            // OrderIDごとにグループ化
            const itemsByOrder = {};
            for (const item of items) {
                if (!itemsByOrder[item.order_id]) {
                    itemsByOrder[item.order_id] = [];
                }
                itemsByOrder[item.order_id].push(item);
            }

            // 印刷済みアイテムIDを収集
            const printedItemIds = [];

            // 注文ごとに印刷
            for (const orderId of Object.keys(itemsByOrder)) {
                const orderItems = itemsByOrder[orderId].filter(item => !processingItemIds.has(item.item_id));
                if (orderItems.length === 0) continue;  // 全て処理中なのでスキップ
                // 処理中セットに追加（二重印刷防止）
                for (const item of orderItems) processingItemIds.add(item.item_id);

                const orderData = {
                    id: orderId,
                    table_name: orderItems[0].table_name,
                    datetime: orderItems[0].added_at || new Date().toISOString(),
                    items: orderItems.map(item => ({
                        name: item.menu_name,
                        menu_name: item.menu_name,
                        quantity: item.qty,
                        qty: item.qty,
                        price: 0,
                        is_new: true
                    }))
                };

                try {
                    // 厨房モードの場合、商品ごとに1枚ずつ印刷
                    if (settings.print_mode === 'kitchen') {
                        for (let i = 0; i < orderItems.length; i++) {
                            const item = orderData.items[i];
                            const singleItemData = {
                                id: orderData.id,
                                table_name: orderData.table_name,
                                datetime: orderData.datetime,
                                items: [item]
                            };
                            await printToDevice(printer, singleItemData, settings);
                            printedItemIds.push(orderItems[i].item_id);
                        }
                    } else {
                        // 伝票モードの場合、全商品を一度に印刷
                        await printToDevice(printer, orderData, settings);
                        for (const item of orderItems) {
                            printedItemIds.push(item.item_id);
                        }
                    }
                } catch (printError) {
                    console.error(`印刷失敗 (${printer.name}, order=${orderId}):`, printError.message);
                    mainWindow.webContents.send('polling-error', `${printer.name}: ${printError.message}`);
                    // 印刷失敗したアイテムは処理中セットから削除（次回再試行できるように）
                    for (const item of orderItems) processingItemIds.delete(item.item_id);

                    // Herokuにエラーログを送信
                    try {
                        await axios.post(`${config.herokuUrl}/api/printer-server/log-error`, {
                            store_id: config.storeId,
                            api_key: config.apiKey,
                            error_type: 'print_error',
                            printer_name: printer.name,
                            order_id: orderId,
                            error_message: printError.message,
                            stack_trace: printError.stack || ''
                        }, { timeout: 5000 });
                    } catch (logError) {
                        console.error('エラーログ送信失敗:', logError.message);
                    }
                    // 印刷失敗したアイテムはmark-printedしない（次回再試行）
                }
            }

            // 印刷成功したアイテムのフラグをDBに更新
            if (printedItemIds.length > 0) {
                await markPrinted(printedItemIds, printType);
                // mark-printed完了後、処理中セットから削除
                for (const id of printedItemIds) processingItemIds.delete(id);
                // lastItemIdも更新（後方互換性）
                for (const item of items) {
                    const newId = item.item_id || 0;
                    if (newId > lastItemId) {
                        lastItemId = newId;
                    }
                }
                saveLastItemId(lastItemId);
            }

            mainWindow.webContents.send('new-orders', items.length);

        } catch (error) {
            console.error(`[${printer.name}] ポーリングエラー:`, error.message);
            writeLog(`[ポーリングエラー] ${printer.name}: ${error.message}`);
            mainWindow.webContents.send('polling-error', `${printer.name}: ${error.message}`);
            await sendLogToHeroku('polling_error', {
                printer_name: printer.name,
                error_message: error.message,
                stack_trace: error.stack || ''
            });
        }
    }
}

// ポーリングを開始
function startPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
    }

    if (config && config.enabled) {
        const interval = config.interval || 10000;
        console.log(`ポーリング開始: ${interval}ms間隔`);
        writeLog(`[ポーリング開始] ${interval}ms間隔`);
        sendLogToHeroku('polling_start', { interval_ms: interval, printers: (config.printers || []).map(p => p.name) });
        pollingInterval = setInterval(checkAndPrint, interval);
        checkAndPrint(); // 即座に1回実行
    }
}

// ポーリングを停止
function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
        console.log('ポーリング停止');
        writeLog('[ポーリング停止]');
        sendLogToHeroku('polling_stop', {});
    }
}

// プリンタをスキャン
async function scanPrinters() {
    return new Promise((resolve) => {
        const printers = [];
        const networkInterfaces = os.networkInterfaces();
        let baseIp = null;

        // ローカルIPアドレスを取得
        for (const name of Object.keys(networkInterfaces)) {
            for (const net of networkInterfaces[name]) {
                if (net.family === 'IPv4' && !net.internal) {
                    const parts = net.address.split('.');
                    if (parts[0] === '192' && parts[1] === '168') {
                        baseIp = `${parts[0]}.${parts[1]}.${parts[2]}`;
                        break;
                    }
                }
            }
            if (baseIp) break;
        }

        if (!baseIp) {
            resolve([]);
            return;
        }

        console.log(`ネットワークスキャン開始: ${baseIp}.x`);

        const promises = [];
        for (let i = 1; i <= 254; i++) {
            const ip = `${baseIp}.${i}`;
            const promise = new Promise((resolveCheck) => {
                const socket = new net.Socket();
                const timeout = setTimeout(() => {
                    socket.destroy();
                    resolveCheck();
                }, 200);

                socket.on('connect', () => {
                    clearTimeout(timeout);
                    console.log(`プリンタ検出: ${ip}:9100`);
                    printers.push({ ip, port: 9100 });
                    socket.destroy();
                    resolveCheck();
                });

                socket.on('error', () => {
                    clearTimeout(timeout);
                    resolveCheck();
                });

                socket.connect(9100, ip);
            });

            promises.push(promise);
        }

        Promise.all(promises).then(() => {
            console.log(`スキャン完了: ${printers.length}台検出`);
            resolve(printers);
        });
    });
}

// 接続テスト
async function testConnection(testConfig) {
    try {
        writeLog('=== 接続テスト開始 ===');
        writeLog(`testConfig: ${JSON.stringify(testConfig)}`);
        writeLog(`herokuUrl: ${testConfig.herokuUrl}`);
        writeLog(`storeId: ${testConfig.storeId}`);
        writeLog(`apiKey: ${testConfig.apiKey}`);
        
        // URLを直接構築してAPIキーを確実に送信
        const url = `${testConfig.herokuUrl}/api/printer-server/new-orders?store_id=${testConfig.storeId}&api_key=${encodeURIComponent(testConfig.apiKey)}&since_item_id=0`;
        
        writeLog(`リクエストURL: ${url}`);
        console.log('[DEBUG] 接続テスト開始');
        console.log('[DEBUG] URL:', url);
        console.log('[DEBUG] API Key:', testConfig.apiKey);
        
        const response = await axios.get(url, {
            timeout: 10000
        });
        
        console.log('[DEBUG] レスポンスステータス:', response.status);
        console.log('[DEBUG] レスポンスデータ:', JSON.stringify(response.data));

        return {
            success: true,
            message: '接続成功！APIキーが正しく設定されています。'
        };
    } catch (error) {
        console.log('[DEBUG] エラー発生:', error.message);
        console.log('[DEBUG] エラーコード:', error.code);
        console.log('[DEBUG] レスポンスステータス:', error.response?.status);
        console.log('[DEBUG] レスポンスデータ:', JSON.stringify(error.response?.data));
        
        if (error.response) {
            // サーバーからレスポンスがある場合
            const data = error.response.data;
            if (error.response.status === 401 || (data && data.ok === false && data.error)) {
                return {
                    success: false,
                    message: `APIキーが正しくありません: ${data.error || 'Unauthorized'}`
                };
            }
        }
        
        if (error.code === 'ECONNABORTED') {
            return {
                success: false,
                message: '接続タイムアウト'
            };
        }
        
        return {
            success: false,
            message: `接続エラー: ${error.message}`
        };
    }
}

// アプリ起動時
app.whenReady().then(async () => {
    createWindow();
    createTray();
    setupAutoLaunch();

    // 設定を読み込んでポーリング開始
    loadConfig();
    const hasLastItemId = loadLastItemId();  // lastItemIdをファイルから復元
    
    if (config && config.enabled) {
        // 初回インストール時（last_item_id.jsonがない場合）はサーバーから最新item_idを取得
        if (!hasLastItemId) {
            await initLastItemIdFromServer();
        }
        startPolling();
    }
});

// すべてのウィンドウが閉じられたとき
app.on('window-all-closed', () => {
    // macOS以外ではアプリを終了しない（トレイに常駐）
    if (process.platform !== 'darwin') {
        // Do nothing - keep running in tray
    }
});

// アプリ終了時
app.on('before-quit', () => {
    stopPolling();
});

// IPC通信ハンドラー
ipcMain.handle('load-config', () => {
    return loadConfig();
});

ipcMain.handle('save-config', async (event, newConfig) => {
    const result = saveConfig(newConfig);
    if (result) {
        stopPolling();
        startPolling();
        // 同期はrenderer.js側のregisterPrintersToHeroku()に一本化（両方呼ぶと重複登録になる）
    }
    return result;
});

ipcMain.handle('scan-printers', async () => {
    return await scanPrinters();
});

ipcMain.handle('test-connection', async (event, testConfig) => {
    return await testConnection(testConfig);
});

ipcMain.handle('add-printer', async (event, printer) => {
    // configがnullの場合は読み込む
    if (!config) {
        config = await loadConfig();
    }
    if (!config.printers) {
        config.printers = [];
    }
    const newId = config.printers.length > 0 
        ? Math.max(...config.printers.map(p => p.id)) + 1 
        : 1;
    printer.id = newId;
    config.printers.push(printer);
    const result = saveConfig(config);
    // 同期はrenderer.js側のregisterPrintersToHeroku()に一本化（両方呼ぶと重複登録になる）
    return result;
});

ipcMain.handle('update-printer', async (event, printer) => {
    if (!config) {
        config = await loadConfig();
    }
    const index = config.printers.findIndex(p => p.id === printer.id);
    if (index !== -1) {
        config.printers[index] = printer;
        const result = saveConfig(config);
        // 同期はrenderer.js側のregisterPrintersToHeroku()に一本化
        return result;
    }
    return false;
});

ipcMain.handle('delete-printer', async (event, printerId) => {
    if (!config) {
        config = await loadConfig();
    }
    config.printers = config.printers.filter(p => p.id !== printerId);
    const result = saveConfig(config);
    // 同期はrenderer.js側のregisterPrintersToHeroku()に一本化
    return result;
});

// 印刷キャンセルハンドラー
ipcMain.handle('cancel-print', () => {
    cancelAllPrinting();
    return true;
});

// テスト印刷ハンドラー
ipcMain.handle('test-print', async (event, printerName) => {
    try {
        if (!config) {
            config = await loadConfig();
        }
        
        const printer = config.printers.find(p => p.name === printerName);
        if (!printer) {
            return { success: false, error: 'プリンタが見つかりません' };
        }
        
        if (!printer.enabled) {
            return { success: false, error: 'プリンタが無効になっています' };
        }
        
        writeLog(`[テスト印刷] ${printerName} へテスト印刷を開始`);
        
        // Herokuにテスト印刷開始ログを送信
        const commandMode = printer.command_mode || 'escpos';
        await sendLogToHeroku('test_print_start', {
            printer_name: printerName,
            command_mode: commandMode,
            ip: printer.ip,
            port: printer.port
        });
        
        // コマンドを生成
        const commands = [];
        
        // 日本語エンコーディング用
        const iconv = require('iconv-lite');
        
        const isStarPRNT = printer.command_mode === 'starprnt';
        
        if (isStarPRNT) {
            // StarPRNT初期化
            commands.push(Buffer.from([0x1B, 0x40]));          // ESC @ (初期化)
            commands.push(Buffer.from([0x1B, 0x24, 0x01]));    // ESC $ 1 (Shift JIS漢字モードON)
            if (printer.rotate_180) {
                commands.push(Buffer.from([0x1B, 0x1D, 0x68, 0x30, 0x01, 0x00, 0x00]));
            }
        } else {
            // ESC/POS (Epson)初期化
            commands.push(Buffer.from([0x1B, 0x40]));          // ESC @ (初期化)
            commands.push(Buffer.from([0x1B, 0x74, 0x00]));    // ESC t 0 (日本語)
            commands.push(Buffer.from([0x1C, 0x43, 0x01]));    // FS C 1 (漢字モードON)
            if (printer.rotate_180) {
                commands.push(Buffer.from([0x1B, 0x7B, 0x01]));  // ESC { 1 (上下反転ON)
            }
        }
        
        // テストメッセージ（センタリング）
        if (isStarPRNT) {
            commands.push(Buffer.from([0x1B, 0x1D, 0x61, 0x01])); // ESC GS a 1 (センタリング)
            commands.push(Buffer.from([0x1B, 0x45]));              // ESC E (太字ON)
            commands.push(Buffer.from([0x1B, 0x69, 0x01, 0x01])); // ESC i 1 1 (2倍サイズ)
            commands.push(iconv.encode('テスト印刷\n', 'Shift_JIS'));
            commands.push(Buffer.from([0x1B, 0x46]));              // ESC F (太字OFF)
            commands.push(Buffer.from([0x1B, 0x69, 0x00, 0x00])); // ESC i 0 0 (通常サイズ)
            commands.push(Buffer.from([0x1B, 0x1D, 0x61, 0x00])); // ESC GS a 0 (左揃え)
            commands.push(iconv.encode('\n', 'Shift_JIS'));
        } else {
            commands.push(Buffer.from([0x1B, 0x61, 0x01])); // センタリング
            commands.push(Buffer.from([0x1B, 0x21, 0x30])); // 文字サイズ2倍
            commands.push(Buffer.from([0x1B, 0x45, 0x01])); // 太字ON
            commands.push(iconv.encode('テスト印刷\n', 'Shift_JIS'));
            commands.push(Buffer.from([0x1B, 0x45, 0x00])); // 太字OFF
            commands.push(Buffer.from([0x1B, 0x21, 0x00])); // 通常サイズ
            commands.push(Buffer.from([0x1B, 0x61, 0x00])); // 左揃えに戻す
            commands.push(iconv.encode('\n', 'Shift_JIS'));
        }
        
        // プリンタ情報
        const now = new Date();
        if (isStarPRNT) {
            commands.push(iconv.encode(`プリンタ名: ${printerName}\n`, 'Shift_JIS'));
            commands.push(iconv.encode(`IPアドレス: ${printer.ip}\n`, 'Shift_JIS'));
            commands.push(iconv.encode(`ポート: ${printer.port}\n`, 'Shift_JIS'));
            commands.push(iconv.encode(`モード: StarPRNT\n`, 'Shift_JIS'));
            commands.push(Buffer.from('\n'));
            commands.push(iconv.encode(`日時: ${now.toLocaleString('ja-JP')}\n`, 'Shift_JIS'));
            commands.push(Buffer.from('\n'));
            commands.push(iconv.encode('========================\n', 'Shift_JIS'));
            commands.push(Buffer.from('\n'));
            commands.push(iconv.encode('○ 接続成功\n', 'Shift_JIS'));
            commands.push(iconv.encode('○ 印刷テスト完了\n', 'Shift_JIS'));
            commands.push(Buffer.from('\n\n\n\n\n'));
        } else {
            commands.push(iconv.encode(`プリンタ名: ${printerName}\n`, 'Shift_JIS'));
            commands.push(iconv.encode(`IPアドレス: ${printer.ip}\n`, 'Shift_JIS'));
            commands.push(iconv.encode(`ポート: ${printer.port}\n`, 'Shift_JIS'));
            commands.push(iconv.encode(`モード: ESC/POS\n`, 'Shift_JIS'));
            commands.push(Buffer.from('\n'));
            commands.push(iconv.encode(`日時: ${now.toLocaleString('ja-JP')}\n`, 'Shift_JIS'));
            commands.push(Buffer.from('\n'));
            commands.push(iconv.encode('========================\n', 'Shift_JIS'));
            commands.push(Buffer.from('\n'));
            commands.push(iconv.encode('○ 接続成功\n', 'Shift_JIS'));
            commands.push(iconv.encode('○ 印刷テスト完了\n', 'Shift_JIS'));
            commands.push(iconv.encode('\n\n\n\n\n', 'Shift_JIS'));
        }
        
        // カット
        if (isStarPRNT) {
            commands.push(Buffer.from([0x1B, 0x64, 0x03])); // ESC d 3 (StarPRNTカット)
        } else {
            commands.push(Buffer.from([0x1D, 0x56, 0x00])); // GS V 0 (ESC/POSカット)
        }
        
        // 全コマンドを結合
        const fullCommand = Buffer.concat(commands);
        
        // プリンタに送信
        await sendToPrinter(printer.ip, printer.port, fullCommand);
        
        writeLog(`[テスト印刷] ${printerName} へテスト印刷を送信しました`);
        
        // Herokuにテスト印刷成功ログを送信
        await sendLogToHeroku('test_print_success', {
            printer_name: printerName,
            command_mode: commandMode
        });
        
        return { success: true, message: 'テスト印刷を送信しました' };
    } catch (error) {
        writeLog(`[テスト印刷エラー] ${error.message}`);
        // Herokuにテスト印刷失敗ログを送信
        const printer2 = config && config.printers ? config.printers.find(p => p.name === printerName) : null;
        await sendLogToHeroku('test_print_error', {
            printer_name: printerName,
            command_mode: printer2 ? (printer2.command_mode || 'escpos') : 'unknown',
            error_message: error.message
        });
        return { success: false, error: error.message };
    }
});

// プリンタにデータを送信する関数
async function sendToPrinter(ip, port, data) {
    return new Promise((resolve, reject) => {
        // キャンセルフラグが立っている場合は送信しない
        if (cancelPrinting) {
            writeLog(`[印刷キャンセル] ${ip}:${port} への送信をスキップしました`);
            resolve();
            return;
        }

        const client = new net.Socket();
        activeSockets.push(client);

        const cleanup = () => {
            const idx = activeSockets.indexOf(client);
            if (idx !== -1) activeSockets.splice(idx, 1);
        };

        client.connect(port, ip, () => {
            writeLog(`[プリンタ接続] ${ip}:${port} に接続しました`);
            client.write(data);
        });
        
        client.on('data', (data) => {
            writeLog(`[プリンタ応答] ${data.toString()}`);
        });
        
        client.on('close', () => {
            cleanup();
            writeLog(`[プリンタ切断] ${ip}:${port} から切断しました`);
            resolve();
        });
        
        client.on('error', (err) => {
            cleanup();
            writeLog(`[プリンタエラー] ${err.message}`);
            reject(err);
        });
        
        // 3秒後に自動的に切断
        setTimeout(() => {
            client.end();
        }, 3000);
    });
}

// 全印刷をキャンセルする関数
function cancelAllPrinting() {
    cancelPrinting = true;
    writeLog('[印刷キャンセル] 全印刷をキャンセルします');

    // 接続中の全ソケットを強制切断
    for (const socket of activeSockets) {
        try { socket.destroy(); } catch (e) {}
    }
    activeSockets = [];

    // 3秒後にキャンセルフラグを解除（次の注文は正常に印刷）
    setTimeout(() => {
        cancelPrinting = false;
        writeLog('[印刷キャンセル] キャンセルフラグを解除しました');
        if (mainWindow) mainWindow.webContents.send('cancel-print-done');
    }, 3000);
}
